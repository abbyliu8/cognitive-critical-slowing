# Data Access

Due to data use agreements, raw data files are not included in this repository. 

## CHARLS Data

The China Health and Retirement Longitudinal Study (CHARLS) data can be obtained from:

**Website**: http://charls.pku.edu.cn/en/

**Registration**: Users must register and agree to the data use agreement before downloading.

**Required Waves**: 
- Wave 1 (2011)
- Wave 2 (2013)
- Wave 3 (2015)
- Wave 4 (2018)
- Wave 5 (2020)

**Required Variables**:
- Demographics: ID, age, gender, education
- Cognitive function: memory (word recall), total cognition score
- Mental health: CES-D depression scale
- Health conditions: hypertension, diabetes
- Biomarkers: CRP, HbA1c, triglycerides (if available)

## ELSA Data

The English Longitudinal Study of Ageing (ELSA) data can be obtained from:

**Website**: https://www.elsa-project.ac.uk/

**Repository**: UK Data Service (https://ukdataservice.ac.uk/)

**Required Waves**:
- Wave 4 (2008-2009)
- Wave 5 (2010-2011)
- Wave 6 (2012-2013)
- Wave 7 (2014-2015)
- Wave 8 (2016-2017)
- Wave 9 (2018-2019)

**Required Variables**:
- ID: idauniq
- Demographics: age, sex, education
- Cognitive function: memory (immediate and delayed recall)
- Mental health: CES-D items

## Data Preparation

After obtaining the raw data, place the merged longitudinal files in this directory:

```
data/
├── CHARLS_merged.csv
├── ELSA_merged.csv
└── README.md
```

Then run the analysis pipeline:

```bash
python src/step1_data_cleaning.py --input data/CHARLS_merged.csv --output data/CHARLS_cleaned.csv
```

## Variable Coding

### Memory Score
- CHARLS: Sum of immediate and delayed word recall (0-20)
- ELSA: Sum of immediate and delayed word recall (0-20)

### Trajectory Groups
- Decline: Bottom tertile of memory slope
- Stable: Middle tertile of memory slope  
- Improved: Top tertile of memory slope

### CSD Indicators
- AR(1): Lag-1 autocorrelation of memory scores
- Variance: Temporal variance of memory scores
- CCI: Standardized composite of AR(1) and variance
